# PRIMA

Fertige Anwendung: https://jarochju.github.io/PRIMA/dist/tetris/index.html

Quellcode: https://github.com/jarochju/PRIMA/tree/master/src/tetris

Designdokument: https://github.com/jarochju/PRIMA/blob/master/concept/Designdokument.pdf
